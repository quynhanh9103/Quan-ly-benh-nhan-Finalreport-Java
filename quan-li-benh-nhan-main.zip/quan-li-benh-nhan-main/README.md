# quan-li-benh-nhan
## gg doc huong dan
https://docs.google.com/document/d/1gvl76fPKmEVoUlpe7fMIbbAPqZqMZPhkAefLt-2mUQE/edit?usp=sharing
